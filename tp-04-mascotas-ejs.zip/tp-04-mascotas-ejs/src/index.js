const express = require("express");
const path = require("path");
const expressLayouts = require("express-ejs-layouts");

const { cargarMascotas } = require("./archivos");

async function iniciarServidor() {
    try {
        // Cargar los datos iniciales
        const mascotas = await cargarMascotas();

        const app = express();

        // Configuración de EJS
        app.set("view engine", "ejs");
        app.set("views", path.join(__dirname, "..", "views"));

        // Configuración del layout
        app.use(expressLayouts);
        app.set("layout", "layouts/main");

        // Recursos estáticos
        app.use(express.static(path.join(__dirname, "..", "public")));

        // Permitir recibir datos de formularios
        app.use(express.urlencoded({ extended: false }));

        // Página inicial
        app.get("/", (req, res) => {
            res.render("inicio", {
                title: "Mascotas en adopción"
            });
        });

        app.get("/mascotas", (req, res) => {
            res.render("mascotas/lista", {
                title: "Catálogo de mascotas",
                mascotas: mascotas
            });
        });

        app.get("/mascotas/nueva", (req, res) => {
            res.render("nueva", {
                title: "Agregar mascota",
                valores: {
                    nombre: "",
                    especie: "",
                    edad: "",
                    estado: "En adopción",
                    descripcion: ""
                },
                error: null
            });
        });

        app.get("/mascotas/:id", (req, res) => {

            const id = Number(req.params.id);

            const mascota = mascotas.find(m => m.id === id);

            if (!mascota) {
                return res.status(404).render("no-encontrado", {
                    title: "Mascota no encontrada"
                });
            }

            res.render("mascotas/detalle", {
                title: `Detalle de ${mascota.nombre}`,
                mascota: mascota
            });
        });

        app.post("/mascotas", (req, res) => {

            const {
                nombre,
                especie,
                edad,
                estado,
                descripcion
            } = req.body;

            const edadNumero = Number(edad);

            const valores = {
                nombre: nombre || "",
                especie: especie || "",
                edad: edad || "",
                estado: estado || "En adopción",
                descripcion: descripcion || ""
            };

            // Validación
            if (
                !valores.nombre.trim() ||
                !valores.especie.trim() ||
                !valores.descripcion.trim() ||
                !Number.isInteger(edadNumero) ||
                edadNumero < 0 ||
                !["En adopción", "Reservada", "Adoptada"].includes(valores.estado)
            ) {

                return res.status(400).render("nueva", {
                    title: "Agregar mascota",
                    valores: valores,
                    error: "Todos los campos son obligatorios y la edad debe ser un número entero mayor o igual a 0."
                });
            }

            // Generar nuevo ID
            const nuevoId =
                mascotas.length > 0
                    ? Math.max(...mascotas.map(m => m.id)) + 1
                    : 1;

            const nuevaMascota = {
                id: nuevoId,
                nombre: valores.nombre.trim(),
                especie: valores.especie.trim(),
                edad: edadNumero,
                descripcion: valores.descripcion.trim(),
                estado: valores.estado,
                imagen: "/img/mascota.svg"
            };

            // Agregar solamente en memoria
            mascotas.push(nuevaMascota);

            // Redireccionar al catálogo
            res.redirect("/mascotas");
        });

        const PORT = 3000;

        app.listen(PORT, () => {
            console.log(`Servidor funcionando en http://localhost:${PORT}`);
        });

    } catch (error) {
        console.error("No se pudieron cargar las mascotas:", error);
    }
}

iniciarServidor();