const fs = require("fs/promises");
const path = require("path");

const rutaMascotas = path.join(
    __dirname,
    "..",
    "datos",
    "mascotas.json"
);

async function cargarMascotas() {
    const contenido = await fs.readFile(rutaMascotas, "utf8");
    return JSON.parse(contenido);
}

module.exports = {
    cargarMascotas
};