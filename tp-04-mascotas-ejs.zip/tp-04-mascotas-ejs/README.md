# Trabajo Práctico 04 - Mascotas en Adopción

Descripción

Aplicación web desarrollada con Node.js, Express y EJS para consultar mascotas en adopción y agregar temporalmente nuevos registros mediante un formulario.

La aplicación utiliza un archivo JSON como fuente de datos inicial. Los nuevos registros se agregan solamente en memoria, por lo que desaparecen cuando se reinicia el servidor.

La aplicación genera páginas HTML mediante EJS y utiliza un layout principal y parciales reutilizables.

Instalación

Para instalar las dependencias del proyecto, ejecutar:

npm install

Las principales dependencias utilizadas son:

Express

EJS

express-ejs-layouts

Ejecución

Para iniciar la aplicación:

npm start

La aplicación queda disponible en:

http://localhost:3000

Para comprobar la sintaxis de los archivos principales se puede ejecutar:

npm run check

Páginas y rutas

La aplicación cuenta con las siguientes rutas:

Método

Ruta

Función

GET

/

Página inicial

GET

/mascotas

Listado de mascotas

GET

/mascotas/nueva

Formulario para agregar una mascota

GET

/mascotas/:id

Detalle de una mascota

POST

/mascotas

Procesamiento del formulario

Si se solicita una mascota cuyo identificador no existe, se responde con código 404 y se muestra una página HTML de error.

Estructura de vistas

Las vistas EJS están organizadas de la siguiente manera:

views/
├── layouts/
│   └── main.ejs
├── partials/
│   ├── encabezado.ejs
│   └── pie.ejs
├── mascotas/
│   ├── lista.ejs
│   └── detalle.ejs
├── inicio.ejs
├── nueva.ejs
└── no-encontrado.ejs

Layout

El layout main.ejs contiene la estructura HTML general de las páginas.

Incluye:

declaración HTML;

idioma español;

codificación;

viewport;

título dinámico;

hoja de estilos;

encabezado;

contenido principal;

pie de página;

archivo JavaScript.

El contenido particular de cada página se inserta mediante:

<%- body %>

Vistas

Las vistas contienen el contenido específico de cada página, por ejemplo el inicio, el listado de mascotas, el detalle y el formulario.

Parciales

Los parciales permiten reutilizar partes comunes de las páginas.

En este proyecto se utilizan:

encabezado.ejs

pie.ejs

El encabezado contiene la navegación y el pie de página aparece en las diferentes páginas mediante el layout.

Recursos estáticos

Los recursos estáticos se encuentran dentro de la carpeta public:

public/
├── css/
│   └── estilos.css
├── img/
│   └── mascota.svg
└── js/
    └── app.js

Express permite acceder a estos recursos mediante express.static.

Por ejemplo:

/css/estilos.css
/img/mascota.svg
/js/app.js

No es necesario colocar /public en las URLs utilizadas dentro de las páginas HTML.

El archivo JavaScript contiene un mensaje de consola para comprobar que el recurso se está cargando correctamente.

Formulario

El formulario permite agregar temporalmente una nueva mascota.

Los campos solicitados son:

nombre;

especie;

edad;

estado;

descripción.

El formulario utiliza:

<form action="/mascotas" method="post">

Cada control posee su correspondiente id y name.

Antes de agregar una mascota se realizan validaciones para comprobar que los campos estén completos y que la edad sea válida.

Cuando se produce un error:

se responde con código 400;

se muestra un mensaje de error;

se utiliza role="alert";

se conservan los valores ingresados por el usuario.

Cuando los datos son correctos:

se genera un nuevo identificador;

se asigna la imagen local /img/mascota.svg;

se agrega la nueva mascota al arreglo en memoria;

se redirige al listado mediante /mascotas.

Persistencia de los datos

Los datos iniciales de las mascotas se encuentran en:

datos/mascotas.json

El archivo contiene los registros iniciales utilizados por la aplicación.

Los nuevos registros enviados mediante el formulario no se guardan nuevamente en el archivo JSON. Se agregan solamente al arreglo que permanece en memoria mientras el servidor está funcionando.

Por este motivo, cuando se reinicia la aplicación, los nuevos registros desaparecen y vuelven a estar disponibles únicamente las mascotas iniciales del archivo JSON.

Flujo del formulario

El recorrido de un registro nuevo es:

Formulario
     ↓
POST /mascotas
     ↓
Validación de datos
     ↓
Agregar mascota en memoria
     ↓
Redirección
     ↓
GET /mascotas
     ↓
Listado actualizado

Si los datos son incorrectos, no se realiza la redirección y se vuelve a mostrar el formulario con los valores ingresados y el mensaje de error correspondiente.

Uso de res.render

res.render permite renderizar una vista EJS y enviarle datos desde el servidor.

Por ejemplo, el servidor puede enviar un arreglo de mascotas a la vista mediante:

res.render("mascotas/lista", {
  mascotas: mascotas
});

La vista recibe esos datos y puede utilizarlos para generar el HTML.

express.static

express.static permite que Express sirva archivos estáticos almacenados dentro de la carpeta public.

En este proyecto se utiliza para servir:

archivos CSS;

imágenes SVG;

archivos JavaScript.

express.urlencoded

express.urlencoded permite que Express pueda interpretar los datos enviados mediante formularios HTML utilizando el método POST.

Gracias a este middleware, los datos enviados desde el formulario están disponibles mediante:

req.body

POST, redirección y GET

Cuando el usuario completa correctamente el formulario, los datos llegan mediante:

POST /mascotas

El servidor valida la información, crea la nueva mascota en memoria y luego realiza una redirección hacia:

/mascotas

El navegador realiza entonces una nueva solicitud:

GET /mascotas

De esta manera se muestra nuevamente el listado incluyendo la mascota agregada.

Persistencia temporal

Los nuevos registros son temporales porque solamente se almacenan en memoria.

No se modifican los datos originales de:

datos/mascotas.json